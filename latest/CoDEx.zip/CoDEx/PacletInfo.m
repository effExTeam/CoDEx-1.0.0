(* Paclet Info File *)

(* created 2018/08/12*)

Paclet[
    Name -> "CoDEx",
    Version -> "1.0.0",
    MathematicaVersion -> "10+",
    Description -> "A package to calculate the Wilson Coefficients of SMEFT operators (up to dimension - 6) to connect some Beyond Standard Model (BSM) theory with weak scale precision observables, using Covariant Derivative Expansion. Works for single and multiple degenerate heavy field propagators, at tree and one-loop level.",
    Creator -> "S. D. Bakshi, J. Chakrabortty, S. K. Patra",
    Extensions -> 
        {
            {"Documentation", Language -> "English", MainPage -> "Tutorials/CoDExOverview"}
        }
]


