(* Paclet Info File *)

(* created 2020/07/06*)

Paclet[
    Name -> "CoDEx",
    Version -> "2.0.0",
    MathematicaVersion -> "10+",
    Description -> "A package to calculate the Wilson Coefficients of SMEFT operators (up to dimension - 6) to connect some Beyond Standard Model (BSM) theory with weak scale precision observables, using Covariant Derivative Expansion. Works for single and multiple degenerate heavy field propagators, at tree and one-loop level.",
    Creator -> "Supratim Das Bakshi",
    Extensions -> 
        {
            {"Documentation", Language -> "English"}
        }
]


