(* Paclet Info File *)

(* created 2018/07/01*)

Paclet[
    Name -> "CoDEx",
    Version -> "1.0.0",
    MathematicaVersion -> "9+",
    Description -> "A practical two-step procedure of using the SMEFT to connect UV models of NP with weak scale precision observables.",
    Creator -> "S. D. Bakshi, J. Chakrabortty, S. K. Patra",
    Extensions -> 
        {
            {"Documentation", Language -> "English", MainPage -> "Tutorials/CoDExOverview"}
        }
]


